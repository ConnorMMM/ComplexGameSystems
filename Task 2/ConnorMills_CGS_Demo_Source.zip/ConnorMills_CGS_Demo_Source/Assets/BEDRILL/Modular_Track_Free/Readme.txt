﻿------------------------------------
Modular Lowpoly Track Free
------------------------------------

	Modular Lowpoly Track Free contains 14 meshes and 14 prefabs with 1 track.

	Features:

		• 7 corners modules.
		• 3 fences modules.
		• 2 straight modules of the road.
		• 1 start/finish.
		• 1 lawn.
		• One texture 64×64 for all meshes.

	Compatible:

		• Unity 2018.4.0f1 or higher.

	Thanks for reviews :)
	
------------------------------------------------------------------
Release notes
------------------------------------------------------------------
	Version 1.3

		Add 2 meshes and 2 prefabs:
		• Track_Corner_90d_type_01_15x15m_quad_free
		• Track_Corner_90d_type_01_30x30m_quad_free
	
	Version 1.2

		• Add Lightmap UV for all meshes
		• 	Add 1 mesh - Lawn_plane_15m_free
		• 	Add 1 prefab - Lawn_plane_15m_free_obs

	Version 1.0 (Initial version)

		• One texture 64×64 for all meshes.
		• Demo scene.
		• 8 meshes and 8 prefabs with 1 track
		• Mobile friendly.
		• Supports all player platforms.
		• Unity and Unity Pro compatible.